package Tres_raya;

public class Celda {

    // Atributos
    private char valor;        //valor de la celda ('X', 'O' o ' ')
    private int fila;          // fila de la celda
    private int columna;       // columna de la celda
    private boolean ocupada;   // celda está ocupada o no

    // Constructor
    public Celda(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
        this.valor = ' ';     // El valor por defecto celda es un espacio en blanco
        this.ocupada = false; // Una celda no está ocupada por defecto
    }

    // obtener el valor de la celda
    public char getValor() {
        return valor;
    }

    //asignar un valor a la celda
    public void setValor(char valor) {
        this.valor = valor;
        this.ocupada = true;  //asigna un valor a la celda, ésta queda ocupada
    }

    // saber si la celda está ocupada o no
    public boolean isOcupada() {
        return ocupada;
    }
}


