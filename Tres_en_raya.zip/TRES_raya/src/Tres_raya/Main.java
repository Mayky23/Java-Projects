package Tres_raya;

public class Main extends Juego{


class TresEnRaya {
    public static void main(String[] args) {
        Juego juego = new Juego();
        juego.jugar();
    }
}
}
