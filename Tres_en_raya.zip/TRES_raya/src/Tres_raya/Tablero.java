package Tres_raya;

public class Tablero{

	 private Celda[][] celdas;

	// Constructor
	 
	    public Tablero() {
	        setCeldas(new Celda[3][3]); //inicializa el array 
	        //recorre el array de celdas y se inicializa con un valor
	        for (int i = 0; i < 3; i++) {
	            for (int j = 0; j < 3; j++) {
	            	//nueva celda y se asigna a la posición
	                getCeldas()[i][j] = new Celda(i, j);
	            }
	        }
	    }

	    public void imprimirTablero() {
	        for (int i = 0; i < 3; i++) { // filas 
	            for (int j = 0; j < 3; j++) { // columnas
	                System.out.print(getCeldas()[i][j].getValor() + " "); // imprime valor de celda
	                if (j < 2) {
	                    System.out.print("| "); // separador vertical
	                }
	            }
	            System.out.println();
	            if (i < 2) {
	                System.out.println("---------");// separador horizontal 
	            }
	        }
	    }

	    public boolean comprobarGanador() {
	        
	    	//Comprueba las filas y las columnas del tablero
	    	
	    	for (int i = 0; i < 3; i++) {
	            if (celdas[i][0].getValor() == celdas[i][1].getValor() && celdas[i][1].getValor() == celdas[i][2].getValor() && celdas[i][0].isOcupada()) {
	                return true;
	            }
	            if (celdas[0][i].getValor() == celdas[1][i].getValor() && celdas[1][i].getValor() == celdas[2][i].getValor() && celdas[0][i].isOcupada()) {
	                return true;
	            }
	        }
	      //Comprueba las diagonales del tablero
	        
	        if (celdas[0][0].getValor() == celdas[1][1].getValor() && celdas[1][1].getValor() == celdas[2][2].getValor() && celdas[0][0].isOcupada()) {
	            return true;
	        }
	        if (celdas[0][2].getValor() == celdas[1][1].getValor() && celdas[1][1].getValor() == celdas[2][0].getValor() && celdas[0][2].isOcupada()) {
	            return true;
	        }
	        
	        return false; //Si no hay ganador, devuelve falso
	    }

	    public void actualizarCelda(int fila, int columna, char valor) {
	        if (!celdas[fila][columna].isOcupada()) {
	            celdas[fila][columna].setValor(valor);
	        }
	    }

		public Celda[][] getCeldas() {
			return celdas;
		}

		public void setCeldas(Celda[][] celdas) {
			this.celdas = celdas;
		}
	}


