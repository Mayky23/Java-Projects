package Tres_raya;

import java.util.Scanner;

public class Juego extends Tablero{

    private Tablero tablero;

    public Juego() {
        tablero = new Tablero();
    }

    public void jugar() {
        Scanner sc = new Scanner(System.in);
        boolean turnoX = true;
        int movimientos = 0;
        while (!tablero.comprobarGanador() && movimientos < 9) { // limite de movimiento (9)
            tablero.imprimirTablero();
            System.out.println("Turno del jugador " + (turnoX ? 'X' : 'O'));
            System.out.print("Ingrese la fila  ej:(0-2): ");
            int fila = sc.nextInt();
            System.out.print("Ingrese la columna  ej:(0-2): ");
            int columna = sc.nextInt();
            // limitador para numeros del user y comprobar si está ocupada
            if (fila >= 0 && fila <= 2 && columna >= 0 && columna <= 2 && !tablero.getCeldas()[fila][columna].isOcupada()) {
                tablero.actualizarCelda(fila, columna, turnoX ? 'X' : 'O');
                turnoX = !turnoX;
                movimientos++;
            } else {
                System.out.println("Movimiento inválido, por favor intente de nuevo.");
            }
        }
        tablero.imprimirTablero();
        if (tablero.comprobarGanador()) {
            System.out.println("Ganador: " + (turnoX ? 'O' : 'X'));
        } else {
            System.out.println("Empate");
        }
    }
}
